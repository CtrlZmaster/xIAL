# Informácie o testovacích súboroch
1. 20 uzlov, 70 hrán
2. 50 uzlov, 178 hrán
3. 80 uzlov, 307 hrán
4. 110 uzlov, 406 hrán
5. 140 uzlov, 480 hrán