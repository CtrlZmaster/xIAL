# Informácie o testovacích súboroch
1. 30 uzlov, 71 hrán, váhy [0,30]
2. 60 uzlov, 134 hrán, váhy [0,70]
3. 90 uzlov, 282 hrán, váhy [0,100]
4. 120 uzlov, 417 hrán, váhy [0,250]
5. 150 uzlov, 557 hrán, váhy [0,350]